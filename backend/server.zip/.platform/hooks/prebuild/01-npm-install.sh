#!/bin/bash
echo "⚙️ Ejecutando npm install con legacy-peer-deps..."
npm install --omit=dev --legacy-peer-deps
